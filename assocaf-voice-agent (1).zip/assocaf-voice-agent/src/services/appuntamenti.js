import { config } from '../config/dotenv.js';

/**
 * Registra un appuntamento chiamando l'endpoint del sito ASSOCAF.
 * L'endpoint scrive nel database e lo rende visibile nella dashboard admin.
 *
 * @param {Object} args - Dati raccolti dall'agente vocale
 * @param {Object} meta - Metadati della chiamata (callSid, callerNumber)
 * @returns {Promise<{ok: boolean, message: string}>}
 */
export async function registraAppuntamento(args, meta = {}) {
  const url = `${config.assocaf.apiUrl}/api/voice/book-appointment`;

  const payload = {
    nome: args.nome || '',
    cognome: args.cognome || '',
    telefono: args.telefono || meta.callerNumber || '',
    email: args.email || '',
    motivo: args.motivo || '',
    giorno: args.giorno || '',
    callSid: meta.callSid || '',
    callerNumber: meta.callerNumber || '',
  };

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.assocaf.apiKey,
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timeout);

    let data = {};
    try {
      data = await res.json();
    } catch {
      data = {};
    }

    if (!res.ok) {
      console.error(`[Appuntamenti] Errore API (${res.status}):`, JSON.stringify(data));
      return {
        ok: false,
        message:
          data && data.error
            ? String(data.error)
            : "Non sono riuscito a registrare l'appuntamento in questo momento.",
      };
    }

    console.log(
      `[Appuntamenti] Registrato: ${payload.nome} ${payload.cognome} - tel ${payload.telefono} - ${payload.motivo} - ${payload.giorno}`
    );
    return {
      ok: true,
      message:
        (data && data.message) ||
        "Appuntamento registrato correttamente. Il cliente sarà ricontattato per conferma.",
    };
  } catch (err) {
    console.error('[Appuntamenti] Errore di rete:', err.message);
    return {
      ok: false,
      message: "Si è verificato un problema tecnico nel salvataggio dell'appuntamento.",
    };
  }
}
